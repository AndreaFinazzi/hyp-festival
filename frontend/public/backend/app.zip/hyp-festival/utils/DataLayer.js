'use strict;'

var local = false;
var types = require('pg').types;

types.setTypeParser(1082, val => val);

module.exports.schema = {
    tables: {
        ARTISTIC_EVENT: "artistic_event",
        CONTENT: 'pages',
        PERFORMANCE: "performance",
        PERFORMER: "performer",
        PHOTO: "photo",
        PHOTO_GALLERY: "photo_gallery",
        RESERVATION: "reservation",
        SAME_DAY_EVENTS: "same_day_events",
        SEMINAR: "seminar",
        USER: "user"
    },
    fields: {
      PK: "id",
      FK: "id_",
      TYPE: "type",
      DATE: "date",
      EMAIL: "email",
      NAME: 'name',
      PASSWORD: "password"
    }
}

module.exports.database = require('knex')({
    client: 'pg',
    connection: local ? {
      host : '127.0.0.1',
      user : 'postgres',
      password : 'postgres',
      database : 'hyp-festival-2019'
    } :
    'postgres://tbtidwmljmpdti:75c29337fe130a66c1cdf115d6dcb4841694281b32d5111511cdca83cefd7321@ec2-54-228-246-214.eu-west-1.compute.amazonaws.com:5432/da80si9bo3r8t6?ssl=true'
  });
